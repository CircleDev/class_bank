import 'package:class_bank/main.dart';
import 'package:class_bank/ui/screens/bottom_nav_bar_screen.dart';
import 'package:class_bank/ui/theme.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BankApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      theme: isDarkMode ? darkThemeData(context) : themeData(context),
      home: BottomNavBarScreen(),
    );
  }
}
