import 'package:class_bank/model/class_list_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PayedCard extends StatefulWidget {
  final ClassMember member;
  const PayedCard({Key key, this.member}) : super(key: key);

  @override
  _PayedCardState createState() => _PayedCardState();
}

class _PayedCardState extends State<PayedCard> {
  int totalPayed = 0;
  int payedInThisTarget = 0;
  List<String> collectionsID = [];

  @override
  void initState() {
    FirebaseFirestore.instance
        .collection('history_payments')
        .get()
        .then((value) => value.docs.forEach((element) {
              collectionsID.add(element.get('users_collection'));
            }));

    payedInThisTarget = int.parse(widget.member.status);

    Future.delayed(Duration(seconds: 1)).then((value) {
      _getPayedCount(collectionsID);
    });
    super.initState();
  }

  void _getPayedCount(List<String> collections) {
    for (final String collectionId in collections) {
      FirebaseFirestore.instance
          .collection(collectionId)
          .where('name', isEqualTo: widget.member.name)
          .get()
          .then((value) => value.docs.forEach((element) {
                setState(() {
                  totalPayed += int.parse(element.get('status'));
                });
              }))
          .catchError((error) => print(error));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(widget.member.name),
        subtitle: Text('Всего сдал(-а) - ${totalPayed + payedInThisTarget}'),
      ),
    );
  }
}
