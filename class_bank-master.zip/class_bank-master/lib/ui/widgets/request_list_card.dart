import 'package:class_bank/model/request_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class RequestCard extends StatelessWidget {
  final RequestModel requestMember;
  final String cost;

  const RequestCard({Key key, this.requestMember, this.cost}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        title: Center(
          child: Text(requestMember.name),
        ),
        subtitle: Column(
          children: <Widget>[
            Text('Отправил(-а) запрос на проверку'),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Expanded(
                  flex: 10,
                  child: OutlineButton(
                    onPressed: () => _requestAccepted(true),
                    highlightedBorderColor: Theme.of(context).accentColor,
                    borderSide:
                        BorderSide(color: Theme.of(context).accentColor),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(Icons.done),
                        Padding(
                          padding: EdgeInsets.only(left: 6),
                          child: Text('Подтвердить'),
                        ),
                      ],
                    ),
                  ),
                ),
                Spacer(), // добавляем отступ между кнопками
                Expanded(
                  flex: 10,
                  child: OutlineButton(
                    onPressed: () => _requestAccepted(false),
                    highlightedBorderColor: Theme.of(context).accentColor,
                    borderSide:
                        BorderSide(color: Theme.of(context).accentColor),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(Icons.close),
                        Padding(
                          padding: EdgeInsets.only(left: 6),
                          child: Text('Отклонить'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  _requestAccepted(bool accepted) async {
    // всё просто: принято - обновляем поле delivered по пути users/{USER_ID}/
    // а после удаляем запрос
    final DateTime now = DateTime.now();
    final DateFormat formatter = DateFormat('HH:mm, dd.MM.yyyy');
    final String formatted = formatter.format(now);

    DocumentSnapshot title = await FirebaseFirestore.instance
        .collection('info')
        .doc('payments')
        .get();

    int titleCost = int.parse(title['cost'].toString());
    int balance = int.parse(title['balance'].toString());
    String newBalance = (balance + titleCost).toString();

    if (accepted) {
      CollectionReference users =
          FirebaseFirestore.instance.collection('users');
      CollectionReference info = FirebaseFirestore.instance.collection('info');
      users
          .doc(requestMember.requestedId)
          .update({'status': cost, 'time': formatted})
          .then((value) => print("User Updated"))
          .catchError((error) => print("Failed to update user: $error"));

      info.doc('payments').update({'balance': newBalance}).then(
          (value) => print('Sum balance success'));
      _deleteRequest(requestMember.docId);
    } else {
      // не принято - просто удаляем запрос
      _deleteRequest(requestMember.docId);
    }
  }

  _deleteRequest(String id) {
    CollectionReference request =
        FirebaseFirestore.instance.collection('requests');
    request
        .doc(id)
        .delete()
        .then((value) => print("User Deleted"))
        .catchError((error) => print("Failed to delete user: $error"));
  }
}
