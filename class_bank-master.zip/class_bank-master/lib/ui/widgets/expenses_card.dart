import 'package:class_bank/model/expenses_model.dart';
import 'package:flutter/material.dart';

class ExpensesCard extends StatelessWidget {
  final Expenses expenses;

  const ExpensesCard({Key key, this.expenses}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(expenses.object),
        subtitle: Text('Затрачено: ${expenses.spendedMoney}'),
        trailing: Text(expenses.newBalance),
      ),
    );
  }
}
