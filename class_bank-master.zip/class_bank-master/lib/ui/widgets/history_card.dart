import 'package:class_bank/model/history_model.dart';
import 'package:class_bank/ui/screens/history_preview.dart';
import 'package:flutter/material.dart';

class HistoryCard extends StatefulWidget {
  final History history;
  const HistoryCard({Key key, this.history}) : super(key: key);
  @override
  _HistoryCardState createState() => _HistoryCardState();
}

class _HistoryCardState extends State<HistoryCard> {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text('Цель: ${widget.history.title}'),
        subtitle: Text(
            'Сумма: ${widget.history.cost}, баланс: ${widget.history.balance}'),
        trailing: Text(widget.history.time),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => HistoryPreviewScreen(
                      collectionID: widget.history.collectionID,
                      appBarTitle: widget.history.title,
                      cost: widget.history.cost,
                    )),
          );
        },
      ),
    );
  }
}
