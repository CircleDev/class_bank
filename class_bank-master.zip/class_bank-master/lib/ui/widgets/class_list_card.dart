import 'package:class_bank/model/class_list_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class ClassListCard extends StatefulWidget {
  final ClassMember classMember;
  final String cost;

  const ClassListCard({Key key, this.classMember, this.cost}) : super(key: key);
  @override
  _ClassListCardState createState() => _ClassListCardState();
}

class _ClassListCardState extends State<ClassListCard> {

  String sendStatus = 'Не отправил';
  Color colorSendStatus = Colors.redAccent;

  @override
  Widget build(BuildContext context) {
    if (widget.classMember.status != "0" &&
        widget.classMember.status != widget.cost) {
      sendStatus = 'Отправил часть - ${widget.classMember.status}';
      colorSendStatus = Colors.yellowAccent;
    } else {
      if (widget.classMember.status == widget.cost) {
        sendStatus = 'Отправил - ${widget.classMember.time}';
        colorSendStatus = Theme.of(context).accentColor;
      } else {
        sendStatus = 'Не отправил';
        colorSendStatus = Colors.redAccent;
      }
    }

    return Card(
      // создание карточки, в которой всё за пределами обрезается
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        onLongPress: _longClick,
        // создание ListTile,
        // см. https://api.flutter.dev/flutter/material/ListTile-class.html
        onTap: () => cardClicked(widget.classMember.docId, context),
        title: Text(widget.classMember.name),
        // проверка на статус отправки и показ соотв. текста
        subtitle: Text(sendStatus, style: TextStyle(color: colorSendStatus)),
      ),
    );
  }

  Future<void> cardClicked(String id, BuildContext context) async {
    // получаем актуальное локальное время в формате 10:00, 01.01.2000
    final DateTime now = DateTime.now();
    final DateFormat formatter = DateFormat('HH:mm, dd.MM.yyyy');
    final String formatted = formatter.format(now);

    DocumentSnapshot title = await FirebaseFirestore.instance
        .collection('info')
        .doc('payments')
        .get();

    int titleCost = int.parse(title['cost'].toString());
    int balance = int.parse(title['balance'].toString());
    String sumBalance = (balance + titleCost).toString();
    String minBalance = (balance - titleCost).toString();

    if (!FirebaseAuth.instance.currentUser.isAnonymous) {
      // если вход выполнен через аккаунт, то сменить статус отправки
      // и добавить текущее время
      CollectionReference users =
          FirebaseFirestore.instance.collection('users');
      CollectionReference info = FirebaseFirestore.instance.collection('info');
      users
          .doc(id)
          .update({
            'status': widget.cost == widget.classMember.status? '0': widget.cost,
            'time':  formatted
          })
          .then((value) => print("User Updated"))
          .catchError((error) => print("Failed to update user: $error"));
      String sendBalance = '';
      if (widget.cost == widget.classMember.status) {
        sendBalance = minBalance;
      } else {
        if (widget.classMember.status != '0'){
          sendBalance = (balance + (int.parse(widget.cost) - int.parse(widget.classMember.status))).toString();
        } else {
          sendBalance = sumBalance;
        }

      }

      info.doc('payments').update({'balance': sendBalance}).then(
          (value) => print('Update balance success'));
    } else {
      // если вход не выполнен, то отправить запрос администратору на проверку,
      // передавая ID документа, подавшего запрос, имя - видимый параметр для админа
        CollectionReference requests =
            FirebaseFirestore.instance.collection('requests');
        requests
            .doc(id)
            .set({'id': id, 'name': widget.classMember.name}).then((value) {
          print("Request Added");
          Get.rawSnackbar(
              duration: Duration(seconds: 5),
              title: 'Информация',
              message:
                  'Ваш запрос отправлен администратору, пожалуйста, ожидайте проверки');
        }).catchError((error) {
          Get.rawSnackbar(
              duration: Duration(seconds: 5),
              title: 'Ошибка',
              message: 'Возникла ошибка при отправке запроса:\n$error');
        });

    }
  }

  void _longClick() {
    TextEditingController payedController = TextEditingController();
    FirebaseAuth auth = FirebaseAuth.instance;
    if (!auth.currentUser.isAnonymous) {
      showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10),
              topRight: Radius.circular(10),
            ),
          ),
          builder: (context) => Container(
                padding: MediaQuery.of(context).viewInsets,
                margin: const EdgeInsets.only(top: 10, left: 15, right: 15),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      'Введите отправленную сумму',
                      style: Theme.of(context).textTheme.headline5,
                    ),
                    Padding(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: TextFormField(
                          controller: payedController,
                          textInputAction: TextInputAction.next,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                              labelText: 'Введите сумму',
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Theme.of(context).accentColor)),
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Theme.of(context).accentColor))),
                        )),
                    ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text(
                            'Отмена',
                            style:
                                TextStyle(color: Theme.of(context).accentColor),
                          ),
                          highlightColor:
                              Theme.of(context).accentColor.withOpacity(0.20),
                        ),
                        OutlineButton(
                          child: Text(
                            'Сохранить',
                            style:
                                TextStyle(color: Theme.of(context).accentColor),
                          ),
                          onPressed: () =>
                              _saveNewPayedInfo(payedController.text),
                          highlightedBorderColor: Theme.of(context).accentColor,
                          borderSide:
                              BorderSide(color: Theme.of(context).accentColor),
                        )
                      ],
                    ),
                  ],
                ),
              ));
    }
  }

  Future<void> _saveNewPayedInfo(String item) async {
    Navigator.pop(context);
    final DateTime now = DateTime.now();
    final DateFormat formatter = DateFormat('HH:mm, dd.MM.yyyy');
    final String formatted = formatter.format(now);

    DocumentSnapshot title = await FirebaseFirestore.instance
        .collection('info')
        .doc('payments')
        .get();

    int oldValue = int.parse(widget.classMember.status);
    int newValue = int.parse(item);
    int balance = int.parse(title['balance'].toString());
    String sumBalance = (balance + newValue).toString();
    String minBalance = (balance - newValue).toString();
    if (newValue == 0) {
      minBalance = (balance - oldValue).toString();
    }

    String updateBalance = '';

    if (newValue > oldValue) {
      updateBalance = sumBalance;
    } else {
      updateBalance = minBalance;
    }

    CollectionReference info = FirebaseFirestore.instance.collection('info');
    info.doc('payments').update({'balance': updateBalance}).then(
        (value) => print('Update balance success'));

    CollectionReference users = FirebaseFirestore.instance.collection('users');
    users
        .doc(widget.classMember.docId)
        .update({
          'status': item,
          'time': formatted
        })
        .then((value) => print("User Updated"))
        .catchError((error) => print("Failed to update user: $error"));
  }
}
