import 'package:class_bank/model/class_list_model.dart';
import 'package:class_bank/ui/widgets/total_payed_card.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class TotalPayedScreen extends StatefulWidget {
  @override
  _TotalPayedScreenState createState() => _TotalPayedScreenState();
}

class _TotalPayedScreenState extends State<TotalPayedScreen> {
  @override
  Widget build(BuildContext context) {
    CollectionReference collectionReference =
    FirebaseFirestore.instance.collection('users');
    Stream<QuerySnapshot> stream;
    stream = collectionReference.snapshots();

    return Scaffold(
      appBar: AppBar(
        title: Text('Всего отправлено'),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder(
              stream: stream,
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (!snapshot.hasData) return _buildLoadingIndicator();
                return ListView(
                  children: snapshot.data.docs.map((document) {
                    return PayedCard(
                      member: ClassMember.fromMap(document.data(), document.id),
                    );
                  }).toList(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Center _buildLoadingIndicator() {
    return Center(
      child: CircularProgressIndicator(),
    );
  }
}
