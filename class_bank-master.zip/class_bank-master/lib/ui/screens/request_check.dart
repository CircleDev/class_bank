import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:class_bank/ui/widgets/request_list_card.dart';
import 'package:class_bank/model/request_model.dart';

class ClassRequestCheck extends StatefulWidget {
  ClassRequestCheck({Key key}) : super(key: key);

  @override
  _ClassRequestCheckState createState() => _ClassRequestCheckState();
}

class _ClassRequestCheckState extends State<ClassRequestCheck> {
  String cost = '';
  @override
  void initState() {
    _getSettings();
    super.initState();
  }

  _getSettings() async {
    DocumentSnapshot title = await FirebaseFirestore.instance
        .collection('info')
        .doc('payments')
        .get();
    cost = title['cost'].toString();
  }

  @override
  Widget build(BuildContext context) {
    // переменная Firebase, которая обращается по пути
    // requests/ ко всем документам
    CollectionReference collectionReference =
        FirebaseFirestore.instance.collection('requests');
    // переменная поток, содержащая документы Firebase
    Stream<QuerySnapshot> stream;
    stream = collectionReference.snapshots();

    return Scaffold(
      body: SafeArea(
        child: StreamBuilder(
          stream: stream,
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            // показываем круговой индикатор загрузки,
            // когда нет данных в снапшоте. А они там будут хоть какие-то,
            // даже если нет документов
            if (!snapshot.hasData) return _buildLoadingIndicator();
            return ListView(
              children: snapshot.data.docs.map((document) {
                // создание списка из карточек RequestCard, UI карточки находится
                // по пути ui/widgets/request_list_card.dart
                return RequestCard(
                  // передаём данные для карточки
                  requestMember:
                      RequestModel.fromMap(document.data(), document.id),
                  cost: cost,
                );
              }).toList(),
            );
          },
        ),
      ),
    );
  }

  Center _buildLoadingIndicator() {
    // просто круговой индикатор загрузки
    return Center(
      child: CircularProgressIndicator(),
    );
  }
}
