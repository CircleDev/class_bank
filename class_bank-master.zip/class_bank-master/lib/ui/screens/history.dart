import 'package:class_bank/model/history_model.dart';
import 'package:class_bank/ui/widgets/history_card.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class HistoryScreen extends StatefulWidget {
  @override
  _HistoryScreenState createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  @override
  Widget build(BuildContext context) {
    CollectionReference collectionReference =
        FirebaseFirestore.instance.collection('history_payments');
    Stream<QuerySnapshot> stream;
    stream = collectionReference.snapshots();

    return Scaffold(
      body: StreamBuilder(
        stream: stream,
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) return _buildLoadingIndicator();
          return ListView(
            children: snapshot.data.docs
                .map((document) {
                  return HistoryCard(
                      history: History.fromMap(document.data(), document.id));
                })
                .toList()
                .reversed
                .toList(),
          );
        },
      ),
    );
  }
}

Center _buildLoadingIndicator() {
  return Center(
    child: CircularProgressIndicator(),
  );
}
