import 'package:class_bank/model/class_list_model.dart';
import 'package:class_bank/ui/widgets/class_list_card.dart';
import 'package:class_bank/ui/widgets/history_preview_card.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class HistoryPreviewScreen extends StatefulWidget {
  final String collectionID;
  final String appBarTitle;
  final String cost;

  const HistoryPreviewScreen(
      {Key key, this.collectionID, this.appBarTitle, this.cost})
      : super(key: key);
  @override
  _HistoryPreviewScreenState createState() => _HistoryPreviewScreenState();
}

class _HistoryPreviewScreenState extends State<HistoryPreviewScreen> {
  @override
  Widget build(BuildContext context) {
    CollectionReference collectionReference =
        FirebaseFirestore.instance.collection(widget.collectionID);
    Stream<QuerySnapshot> stream;
    stream = collectionReference.snapshots();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.appBarTitle),
      ),
      body: Center(
        child: StreamBuilder(
          stream: stream,
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData) return _buildLoadingIndicator();
            return ListView(
              children: snapshot.data.docs.map((document) {
                return HistoryPreviewCard(
                  classMember:
                      ClassMember.fromMap(document.data(), document.id),
                  collectionIDtoEdit: widget.collectionID,
                  cost: widget.cost,
                );
              }).toList(),
            );
          },
        ),
      ),
    );
  }
}

Center _buildLoadingIndicator() {
  return Center(
    child: CircularProgressIndicator(),
  );
}
