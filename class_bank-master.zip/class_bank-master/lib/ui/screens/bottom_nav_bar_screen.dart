import 'package:class_bank/ui/screens/control_screen.dart';
import 'package:class_bank/ui/screens/expenses_screen.dart';
import 'package:class_bank/ui/screens/history.dart';
import 'package:class_bank/ui/screens/total_payed_screen.dart';
import 'package:class_bank/ui/theme.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'class_list.dart';

class BottomNavBarScreen extends StatefulWidget {
  @override
  _BottomNavBarScreenState createState() => _BottomNavBarScreenState();
}

class _BottomNavBarScreenState extends State<BottomNavBarScreen> {
  TextEditingController balanceController = TextEditingController();
  final PageStorageBucket bucket = PageStorageBucket();
  FirebaseAuth auth = FirebaseAuth.instance;
  bool test = false;
  int _selectedIndex = 0;
  String appbarText = 'Список людей';
  String titleText = 'загрузка...';
  String titleCost = 'загрузка...';
  String balance = 'загрузка...';

  final List<Widget> pages = [
    ClassList(),
    ExpensesScreen(),
    HistoryScreen(),
    ControlScreen(),
  ];

  @override
  void initState() {
    _getData();
    super.initState();
  }

  _getData() async {
    DocumentSnapshot title = await FirebaseFirestore.instance
        .collection('info')
        .doc('payments')
        .get();

    setState(() {
      // получаем данные и сообщаем флаттеру, что нужно
      // перерисовать виджеты с новыми данными
      titleText = title['title'].toString();
      titleCost = title['cost'].toString();
      balance = title['balance'].toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    _getData();
    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
            onTap: _editBalance,
            child: Text(_selectedIndex == 0 ? 'Баланс: $balance' : appbarText)),
        actions: [
          _selectedIndex == 0
              ? IconButton(
                  tooltip: 'Всего отправлено',
                  icon: Icon(Icons.receipt_outlined),
                  onPressed: _totalPayedList,
                )
              : Container(),
          _selectedIndex == 2
              ? !auth.currentUser.isAnonymous
                  ? IconButton(
                      icon: Icon(Icons.refresh_outlined),
                      onPressed: _resetUsers,
                      tooltip: 'Сбросить пользователей',
                    )
                  : Container()
              : Container(),
          _selectedIndex == 3
              ? IconButton(
                  icon: Get.isDarkMode
                      ? Icon(Icons.brightness_5_outlined)
                      : Icon(Icons.nights_stay_outlined),
                  onPressed: _changeTheme,
                )
              : Container()
        ],
      ),
      body: PageStorage(
        bucket: bucket,
        child: pages[_selectedIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        backgroundColor: Theme.of(context).primaryColor,
        selectedItemColor: Theme.of(context).accentColor,
        unselectedItemColor: Theme.of(context).textSelectionColor,
        selectedFontSize: 14,
        unselectedFontSize: 14,
        showUnselectedLabels: false,
        onTap: onTabTapped,
        items: [
          BottomNavigationBarItem(
            label: 'Список',
            icon: Icon(Icons.people_outline),
          ),
          BottomNavigationBarItem(
            label: 'Расходы',
            icon: Icon(Icons.timeline_outlined),
          ),
          BottomNavigationBarItem(
            label: 'История',
            icon: Icon(Icons.history_outlined),
          ),
          BottomNavigationBarItem(
            label: 'Управление',
            icon: Icon(Icons.settings_outlined),
          ),
        ],
      ),
    );
  }

  onTabTapped(int value) {
    setState(() {
      _selectedIndex = value;
      switch (value) {
        case 0:
          appbarText = 'Список людей';
          break;
        case 1:
          appbarText = 'Расходы';
          break;
        case 2:
          appbarText = 'История';
          break;
        case 3:
          appbarText = 'Управление';
          break;
      }
    });
  }

  void _resetUsers() {
    showModalBottomSheet(
        context: context,
        isDismissible: false,
        isScrollControlled: true,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          ),
        ),
        builder: (context) => Container(
              padding: MediaQuery.of(context).viewInsets,
              margin: const EdgeInsets.only(top: 15, left: 15, right: 15),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: Text(
                      'Подтвердите сброс',
                      style: TextStyle(fontSize: 22),
                    ),
                  ),
                  Text(
                      'Это действие сбросит платёжное состояние пользователей, цель и сумму сбора'),
                  ButtonBar(children: <Widget>[
                    FlatButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text(
                        'Отмена',
                        style: TextStyle(color: Theme.of(context).accentColor),
                      ),
                      highlightColor:
                          Theme.of(context).accentColor.withOpacity(0.20),
                    ),
                    OutlineButton(
                      onPressed: _doResetUsers,
                      highlightedBorderColor: Theme.of(context).accentColor,
                      borderSide:
                          BorderSide(color: Theme.of(context).accentColor),
                      child: Text(
                        'Сбросить',
                        style: TextStyle(color: Theme.of(context).accentColor),
                      ),
                    )
                  ])
                ],
              ),
            ));
  }

  void _doResetUsers() {
    Navigator.pop(context);
    var collectionID = 'z_history_${DateTime.now().millisecondsSinceEpoch}';
    var time = DateTime.now();
    var formatter = DateFormat('HH:mm, dd.MM.yyyy');
    String nowDate = formatter.format(time);

    CollectionReference historyPayments =
        FirebaseFirestore.instance.collection('history_payments');
    historyPayments.doc(collectionID).set({
      'balance': balance,
      'title': titleText,
      'cost': titleCost,
      'time': nowDate,
      'users_collection': collectionID
    }).then((value) => print('Success add payments'));

    CollectionReference historyUsers =
        FirebaseFirestore.instance.collection(collectionID);
    CollectionReference users = FirebaseFirestore.instance.collection('users');
    users.get().then((ds) {
      if (ds != null) {
        // создаём цикл, перебирая каждый документ
        ds.docs.forEach((value) {
          // обновляем поля в каждом документе
          historyUsers
              .doc(value.id)
              .set({
                'name': value['name'],
                'status': value['status'],
                'time': value['time']
              })
              .then((result) => print("Success reset - ${value.id}"))
              .catchError((error) => print("Failed to reset user: $error"));
        });
      }
    });
    // получаем все документы, проверяем, не равны ли они null
    users.get().then((ds) {
      if (ds != null) {
        // создаём цикл, перебирая каждый документ
        ds.docs.forEach((value) {
          // обновляем поля в каждом документе
          users
              .doc(value.id)
              .update({'time': '', 'status': '0'})
              .then((result) => print("Success reset - ${value.id}"))
              .catchError((error) => print("Failed to reset user: $error"));
        });
      }
    });
  }

  void _editBalance() {
    if (!auth.currentUser.isAnonymous) {
      if (_selectedIndex == 0) {
        showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(10),
                topRight: Radius.circular(10),
              ),
            ),
            builder: (context) => Container(
                  padding: MediaQuery.of(context).viewInsets,
                  margin: const EdgeInsets.only(top: 10, left: 15, right: 15),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(
                        'Введите новый баланс',
                        style: Theme.of(context).textTheme.headline5,
                      ),
                      Padding(
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: TextFormField(
                            controller: balanceController,
                            textInputAction: TextInputAction.next,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                                labelText: 'Введите сумму',
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Theme.of(context).accentColor)),
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Theme.of(context).accentColor))),
                          )),
                      ButtonBar(
                        children: <Widget>[
                          FlatButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text(
                              'Отмена',
                              style: TextStyle(
                                  color: Theme.of(context).accentColor),
                            ),
                            highlightColor:
                                Theme.of(context).accentColor.withOpacity(0.20),
                          ),
                          OutlineButton(
                            child: Text(
                              'Сохранить',
                              style: TextStyle(
                                  color: Theme.of(context).accentColor),
                            ),
                            onPressed: _updateBalance,
                            highlightedBorderColor:
                                Theme.of(context).accentColor,
                            borderSide: BorderSide(
                                color: Theme.of(context).accentColor),
                          )
                        ],
                      ),
                    ],
                  ),
                ));
      }
    }
  }

  void _updateBalance() {
    CollectionReference users = FirebaseFirestore.instance.collection('info');
    users
        .doc('payments')
        .update({'balance': balanceController.text})
        .then((value) => print("Balance Updated"))
        .catchError((error) => print("Failed to update Balance: $error"));
    Navigator.pop(context);

    setState(() {
      balance = balanceController.text;
    });
  }

  Future<void> _changeTheme() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (Get.isDarkMode) {
      Get.changeTheme(themeData(context));
      prefs.setString('selectedTheme', 'light');
    } else {
      Get.changeTheme(darkThemeData(context));
      prefs.setString('selectedTheme', 'dark');
    }
  }

  void _totalPayedList() {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => TotalPayedScreen()));
  }
}
