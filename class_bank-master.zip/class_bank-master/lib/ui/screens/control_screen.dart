import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'request_check.dart';

class ControlScreen extends StatefulWidget {
  @override
  _ControlScreenState createState() => _ControlScreenState();
}

class _ControlScreenState extends State<ControlScreen> {
  TextEditingController emailController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();

  // ключ ID для Scaffold, используется для показа snackbar
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  FirebaseAuth auth = FirebaseAuth.instance;
  var isAdmin = false;

  @override
  void initState() {
    if (!auth.currentUser.isAnonymous) {
      isAdmin = true;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: isAdmin
            ? ClassRequestCheck()
            : Center(
                child: Padding(
                padding: EdgeInsets.all(12),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlineButton(
                    onPressed: () => _loginInAccount(),
                    highlightedBorderColor: Theme.of(context).accentColor,
                    borderSide:
                        BorderSide(color: Theme.of(context).accentColor),
                    child: Text('Войти в аккаунт администратора'),
                  ),
                ),
              )));
  }

  void _loginInAccount() {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          ),
        ),
        builder: (context) => Container(
              padding: MediaQuery.of(context).viewInsets,
              margin: const EdgeInsets.only(top: 10, left: 15, right: 15),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    'Войдите в аккаунт',
                    style: Theme.of(context).textTheme.headline5,
                  ),
                  Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: TextFormField(
                        controller: emailController,
                        textInputAction: TextInputAction.next,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                            labelText: 'Введите email',
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Theme.of(context).accentColor)),
                            focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Theme.of(context).accentColor))),
                      )),
                  TextFormField(
                    controller: passwordController,
                    textInputAction: TextInputAction.done,
                    keyboardType: TextInputType.visiblePassword,
                    decoration: InputDecoration(
                        labelText: 'Введите пароль',
                        border: OutlineInputBorder(),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Theme.of(context).accentColor)),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Theme.of(context).accentColor))),
                  ),
                  ButtonBar(
                    children: <Widget>[
                      FlatButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          'Отмена',
                          style:
                              TextStyle(color: Theme.of(context).accentColor),
                        ),
                        highlightColor:
                            Theme.of(context).accentColor.withOpacity(0.20),
                      ),
                      OutlineButton(
                        child: Text(
                          'Войти',
                          style:
                              TextStyle(color: Theme.of(context).accentColor),
                        ),
                        onPressed: _accountMakeLogin,
                        highlightedBorderColor: Theme.of(context).accentColor,
                        borderSide:
                            BorderSide(color: Theme.of(context).accentColor),
                      )
                    ],
                  ),
                ],
              ),
            ));
  }

  void _accountMakeLogin() async {
    try {
      await FirebaseAuth.instance.signOut();
      await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: emailController.text, password: passwordController.text);
      Navigator.pop(context);
      Get.rawSnackbar(title: 'Информация', message: 'Вход выполнен успешно');
      setState(() {});
    } on FirebaseAuthException {
      await FirebaseAuth.instance.signInAnonymously();
      Navigator.pop(context);
      Get.rawSnackbar(title: 'Информация', message: 'Данные введены неверно');
      setState(() {});
    }
  }
}
