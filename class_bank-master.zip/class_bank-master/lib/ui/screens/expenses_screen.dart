import 'package:class_bank/model/expenses_model.dart';
import 'package:class_bank/ui/widgets/expenses_card.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ExpensesScreen extends StatefulWidget {
  @override
  _ExpensesScreenState createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen> {
  FirebaseAuth auth = FirebaseAuth.instance;
  TextEditingController objectController = TextEditingController();
  TextEditingController spendedMoneyController = TextEditingController();
  int balance = 0;

  @override
  void initState() {
    _getData();
    super.initState();
  }

  _getData() async {
    DocumentSnapshot title = await FirebaseFirestore.instance
        .collection('info')
        .doc('payments')
        .get();

    setState(() {
      // получаем данные и сообщаем флаттеру, что нужно
      // перерисовать виджеты с новыми данными
      balance = int.parse(title['balance']);
    });
  }

  @override
  Widget build(BuildContext context) {
    CollectionReference collectionReference =
        FirebaseFirestore.instance.collection('expenses');
    Stream<QuerySnapshot> stream;
    stream = collectionReference.snapshots();

    return Scaffold(
      body: StreamBuilder(
        stream: stream,
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) return _buildLoadingIndicator();
          return ListView(
            children: snapshot.data.docs.map((document) {
              return ExpensesCard(
                  expenses: Expenses.fromMap(document.data(), document.id));
            }).toList(),
          );
        },
      ),
      floatingActionButton: !auth.currentUser.isAnonymous
          ? FloatingActionButton(
              child: Icon(Icons.add_outlined),
              backgroundColor: Theme.of(context).primaryColor,
              foregroundColor: Theme.of(context).accentColor,
              onPressed: _createNewExpense,
            )
          : null,
    );
  }

  void _createNewExpense() {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          ),
        ),
        builder: (context) => Container(
              padding: MediaQuery.of(context).viewInsets,
              margin: const EdgeInsets.only(top: 10, left: 15, right: 15),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    'Создать расход',
                    style: Theme.of(context).textTheme.headline5,
                  ),
                  Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: TextFormField(
                        controller: objectController,
                        textInputAction: TextInputAction.next,
                        keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                            labelText: 'Введите предмет расхода',
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Theme.of(context).accentColor)),
                            focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Theme.of(context).accentColor))),
                      )),
                  TextFormField(
                    controller: spendedMoneyController,
                    textInputAction: TextInputAction.done,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                        labelText: 'Введите затраченную сумму',
                        border: OutlineInputBorder(),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Theme.of(context).accentColor)),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Theme.of(context).accentColor))),
                  ),
                  ButtonBar(
                    children: <Widget>[
                      FlatButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          'Отмена',
                          style:
                              TextStyle(color: Theme.of(context).accentColor),
                        ),
                        highlightColor:
                            Theme.of(context).accentColor.withOpacity(0.20),
                      ),
                      OutlineButton(
                        child: Text(
                          'Сохранить',
                          style:
                              TextStyle(color: Theme.of(context).accentColor),
                        ),
                        onPressed: _makeExpense,
                        highlightedBorderColor: Theme.of(context).accentColor,
                        borderSide:
                            BorderSide(color: Theme.of(context).accentColor),
                      )
                    ],
                  ),
                ],
              ),
            ));
  }

  void _makeExpense() {
    Navigator.pop(context);
    int spended = int.parse(spendedMoneyController.text);
    String newBalance = (balance - spended).toString();
    var docID = DateTime.now().millisecondsSinceEpoch;

    CollectionReference users =
        FirebaseFirestore.instance.collection('expenses');
    users.doc(docID.toString()).set({
      'object': objectController.text,
      'cost': spendedMoneyController.text,
      'balance': newBalance
    }).then((value) {
      CollectionReference info = FirebaseFirestore.instance.collection('info');
      info.doc('payments').update({'balance': newBalance}).then(
              (value) => print('Success update balance'));
    }).catchError((error) => print("Failed to update Payments: $error"));


  }

  Center _buildLoadingIndicator() {
    return Center(
      child: CircularProgressIndicator(),
    );
  }
}
