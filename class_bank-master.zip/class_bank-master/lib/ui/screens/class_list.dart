import 'package:class_bank/model/class_list_model.dart';
import 'package:class_bank/ui/widgets/class_list_card.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ClassList extends StatefulWidget {
  @override
  _ClassListState createState() => _ClassListState();
}

class _ClassListState extends State<ClassList> {
  final GlobalKey<ScaffoldState> _scaffoldClassKey = GlobalKey<ScaffoldState>();
  TextEditingController titleController = new TextEditingController();
  TextEditingController costController = new TextEditingController();
  FirebaseAuth auth = FirebaseAuth.instance;
  TextEditingController balanceController = new TextEditingController();
  String titleText = 'загрузка...';
  String titleCost = 'загрузка...';
  String balance = 'загрузка...';

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    // добавляем задержку для того, чтобы быть уверенным,
    // что все виджеты построены и их можно вызывать
    Future.delayed(const Duration(seconds: 1)).then((_) {
      if (!FirebaseAuth.instance.currentUser.isAnonymous) {
        _showSnackbar(
            'Нажмите на человека, чтобы изменить его платёжное состояние');
      } else {
        _showSnackbar(
            'Нажмите на себя в списке, чтобы отправить запрос на проверку');
      }
    });

    // получаем данные о реквизитах
    DocumentSnapshot title = await FirebaseFirestore.instance
        .collection('info')
        .doc('payments')
        .get();

    setState(() {
      // получаем данные и сообщаем флаттеру, что нужно
      // перерисовать виджеты с новыми данными
      titleText = title['title'].toString();
      titleCost = title['cost'].toString();
      balance = title['balance'].toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    CollectionReference collectionReference =
        FirebaseFirestore.instance.collection('users');
    Stream<QuerySnapshot> stream;
    stream = collectionReference.snapshots();

    return Scaffold(
      key: _scaffoldClassKey,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              width: double.infinity,
              child: Padding(
                padding: EdgeInsets.all(8.0),
                child: GestureDetector(
                  onTap: _editPayments,
                  child: Column(
                    children: [
                      Text(
                        'Цель: $titleText',
                        style: TextStyle(fontSize: 22),
                      ),
                      Text(
                        'Сумма: $titleCost',
                        style: TextStyle(fontSize: 18),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Divider(),
            Expanded(
              child: StreamBuilder(
                stream: stream,
                builder: (BuildContext context,
                    AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (!snapshot.hasData) return _buildLoadingIndicator();
                  return ListView(
                    children: snapshot.data.docs.map((document) {
                      return ClassListCard(
                        classMember:
                            ClassMember.fromMap(document.data(), document.id),
                        cost: titleCost,
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSnackbar(String text) {
    // функция для показа snackBar
    _scaffoldClassKey.currentState.showSnackBar(SnackBar(
      behavior: SnackBarBehavior.floating,
      content: Text(text),
    ));
  }

  Center _buildLoadingIndicator() {
    return Center(
      child: CircularProgressIndicator(),
    );
  }

  void _editPayments() {
    if (!auth.currentUser.isAnonymous) {
      showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10),
              topRight: Radius.circular(10),
            ),
          ),
          builder: (context) => Container(
                padding: MediaQuery.of(context).viewInsets,
                margin: const EdgeInsets.only(top: 10, left: 15, right: 15),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      'Введите новые данные',
                      style: Theme.of(context).textTheme.headline5,
                    ),
                    Padding(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: TextFormField(
                          controller: titleController,
                          textInputAction: TextInputAction.next,
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(
                              labelText: 'Введите цель',
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Theme.of(context).accentColor)),
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Theme.of(context).accentColor))),
                        )),
                    TextFormField(
                      controller: costController,
                      textInputAction: TextInputAction.done,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          labelText: 'Введите сумму',
                          border: OutlineInputBorder(),
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Theme.of(context).accentColor)),
                          focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Theme.of(context).accentColor))),
                    ),
                    ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text(
                            'Отмена',
                            style:
                                TextStyle(color: Theme.of(context).accentColor),
                          ),
                          highlightColor:
                              Theme.of(context).accentColor.withOpacity(0.20),
                        ),
                        OutlineButton(
                          child: Text(
                            'Сохранить',
                            style:
                                TextStyle(color: Theme.of(context).accentColor),
                          ),
                          onPressed: _savePayments,
                          highlightedBorderColor: Theme.of(context).accentColor,
                          borderSide:
                              BorderSide(color: Theme.of(context).accentColor),
                        )
                      ],
                    ),
                  ],
                ),
              ));
    }
  }

  void _savePayments() {
    CollectionReference users = FirebaseFirestore.instance.collection('info');
    users
        .doc('payments')
        .update({'title': titleController.text, 'cost': costController.text})
        .then((value) => print("Payments Updated"))
        .catchError((error) => print("Failed to update Payments: $error"));
    Navigator.pop(context);
    setState(() {
      titleText = titleController.text;
      titleCost = costController.text;
    });
  }
}
