class Expenses {
  final String object;
  final String spendedMoney;
  final String newBalance;

  Expenses({this.object, this.spendedMoney, this.newBalance});

  Expenses.fromMap(Map<String, dynamic> data, String id)
      : this(
          object: data['object'],
          spendedMoney: data['cost'],
          newBalance: data['balance'],
        );
}
