// класс, который содержит в себе переменные, к которым можно обращаться,
// получая данные с Firebase. Firebase передаёт данные с помощью map,
// поэтому в самом низу мы парсим мапу, присваивая значения этих полей
// нашим переменным

class ClassMember {
  final String name;
  final String time;
  final String docId;
  final String status;

  const ClassMember({
    this.name,
    this.time,
    this.docId,
    this.status,
  });

  ClassMember.fromMap(Map<String, dynamic> data, String id)
      : this(
          name: data['name'],
          time: data['time'],
          status: data['status'],
          docId: id,
        );
}
