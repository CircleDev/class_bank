class History {
  final String title;
  final String balance;
  final String cost;
  final String collectionID;
  final String time;
  final String status;

  const History({
    this.title,
    this.balance,
    this.cost,
    this.collectionID,
    this.time,
    this.status
  });

  History.fromMap(Map<String, dynamic> data, String id)
      : this(
          title: data['title'],
          balance: data['balance'],
          cost: data['cost'],
          collectionID: data['users_collection'],
          status: data['status'],
          time: data['time'],
        );
}
