class RequestModel {
  final String name;
  final String requestedId;
  final String docId;

  const RequestModel({
    this.name,
    this.requestedId,
    this.docId,
  });

  RequestModel.fromMap(Map<String, dynamic> data, String id)
      : this(
          name: data['name'],
          requestedId: data['id'],
          docId: id,
        );
}
