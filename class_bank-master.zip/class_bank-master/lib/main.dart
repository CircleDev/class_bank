import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';

bool isDarkMode = false;

Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  FirebaseAuth auth = FirebaseAuth.instance;

  SharedPreferences prefs = await SharedPreferences.getInstance();
  if (auth.currentUser == null) {
    await FirebaseAuth.instance.signInAnonymously();
  }

  var brightness = SchedulerBinding.instance.window.platformBrightness;
  isDarkMode = brightness == Brightness.dark;

  // если почему-то тема не определилась, то задаём белую по умолчанию
  if (isDarkMode == null) {
    isDarkMode = false;
  }
  // если пользователь задал свою тему, то подстраиваемся под выбор
  if (prefs.getString('selectedTheme') == 'dark') {
    isDarkMode = true;
  }
  if (prefs.getString('selectedTheme') == 'light') {
    isDarkMode = false;
  }

  runApp(BankApp());
}
